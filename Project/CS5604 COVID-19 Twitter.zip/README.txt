Here is the link to our main GitHub repository (also included in the project report): https://github.com/kanguyen-vn/covidtweet_rr

Because downloading and preprocessing the data for our project could take very long (up to days), we have provided the final data needed for the execution of our models here at this Google Drive link: https://drive.google.com/drive/folders/1TYU0X6IynVSmHxxJ1LprRGl2upSJZ3TT?usp=sharing (needs Virginia Tech access).

Please download these folders and place them in the "data" directory already available in the GitHub repository. You can then disregard steps 2-4 in the "Getting data and training models" instructions section within our main README markdown.