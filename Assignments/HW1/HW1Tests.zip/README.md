This testing code and the two subfolders need to be added at the same directory as your `HW1.ipynb`.

Make sure to install nbimporter with:
```pip install nbimporter --user```

And then run:
```python pytesting.py```

If all tests are passed successfully the output will look like this:
```Testing BSBIIndex.
Building BSBIIndex ...
Done. Begin test cases ...
Results match for query: virginia tech class
Results match for query: many students
Results match for query: the the
Results match for query: illinois computer science
Results match for query: admission vt
Results match for query: virginia tech phd cs
Results match for query: the department of computer science
BSBIIndex test done.
Testing Compressed BSBIIndex.
Building BSBIIndex compressed...
Done. Begin test cases ...
Results match for query: virginia tech class
Results match for query: many students
Results match for query: the the
Results match for query: illinois computer science
Results match for query: admission vt
Results match for query: virginia tech phd cs
Results match for query: the department of computer science
Compressed BSBIIndex test done.```
